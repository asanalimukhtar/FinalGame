using Godot;

public interface IPlayerState
{
	void HandleInput(Player player);
	void Update(Player player, float delta);
}

public class IdleState : IPlayerState
{
	public void HandleInput(Player player)
	{
		if (Input.IsActionJustPressed("ui_accept") && player.IsOnFloor())
		{
			player.State = new JumpState();
			player.Jump();
		}
		else if (Input.IsActionPressed("ui_down"))
		{
			player.State = new DuckState();
		}
		// НЕ переключаем на RunState здесь
	}

	public void Update(Player player, float delta)
	{
		player.PlayAnimation("idle");

		Vector2 velocity = player.Velocity;
		velocity.X = 0;  // стоим на месте
		player.Velocity = velocity;
	}
}

public class RunState : IPlayerState
{
	public void HandleInput(Player player)
	{
		if (Input.IsActionJustPressed("ui_accept") && player.IsOnFloor())
		{
			player.State = new JumpState();
			player.Jump();
		}
		else if (Input.IsActionPressed("ui_down"))
		{
			player.State = new DuckState();
		}
		// игрок всегда бежит вправо, не переключаем в Idle
	}

	public void Update(Player player, float delta)
	{
		player.PlayAnimation("run");

		Vector2 velocity = player.Velocity;
		velocity.X = 300;  // двигаемся только вправо
		player.Velocity = velocity;
	}
}

public class JumpState : IPlayerState
{
	public void HandleInput(Player player)
	{
		if (player.IsOnFloor())
		{
			player.State = new IdleState();
		}
	}

	public void Update(Player player, float delta)
	{
		player.PlayAnimation("jump");
	}
}

public class DuckState : IPlayerState
{
	public void HandleInput(Player player)
	{
		if (Input.IsActionJustPressed("ui_accept") && player.IsOnFloor())
		{
			player.State = new JumpState();
			player.Jump();
		}
		else if (!Input.IsActionPressed("ui_down"))
		{
			player.State = new IdleState();
		}
	}

	public void Update(Player player, float delta)
	{
		player.PlayAnimation("duck");
	}
}
